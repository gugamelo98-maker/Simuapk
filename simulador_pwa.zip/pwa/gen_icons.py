from PIL import Image, ImageDraw, ImageFont
import os

out = '/tmp/claude-0/-home-claude/351e0c26-f632-5a9e-adfd-c51c6885d5f9/scratchpad/pwa'

for size in [192, 512]:
    img = Image.new('RGB', (size, size), '#1A1A2E')
    draw = ImageDraw.Draw(img)
    # Gold circle
    pad = size // 6
    draw.ellipse([pad, pad, size-pad, size-pad], outline='#B8940A', width=size//20)
    # S letter
    fs = size // 3
    try:
        font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', fs)
    except:
        font = ImageFont.load_default()
    bbox = draw.textbbox((0,0), 'S', font=font)
    tw, th = bbox[2]-bbox[0], bbox[3]-bbox[1]
    draw.text(((size-tw)//2, (size-th)//2 - bbox[1]//2), 'S', fill='#B8940A', font=font)
    img.save(os.path.join(out, f'icon-{size}.png'))
    print(f'icon-{size}.png ok')
